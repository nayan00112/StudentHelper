from django.apps import AppConfig


class ChataiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'chatai'
